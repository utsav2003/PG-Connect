import React from "react";
import { Navbar, Nav, Button } from "react-bootstrap";
import { Link } from "react-router-dom";

const AppNavbar = () => {
  return (
    <Navbar
      sticky="top"
      collapseOnSelect
      expand="lg"
      bg="light"
      variant="light"
      className="px-4 py-2"
    >
      <Link to="/" style={{ textDecoration: "none", color: "black" }}>
        <Navbar.Brand
          style={{ fontWeight: "bold", fontSize: "2rem", marginRight: "auto" }}
        >
          PGConnect
        </Navbar.Brand>
      </Link>
      <Navbar.Toggle aria-controls="responsive-navbar-nav" />
      <Navbar.Collapse
        id="responsive-navbar-nav"
        className="justify-content-end"
      >
        <Nav className="ml-auto">
          <Nav.Link
            style={{
              color: "black",
              fontSize: "1.2rem",
              marginRight: "1.2rem",
            }}
          >
            <Link to="/" style={{ textDecoration: "none", color: "black" }}>
              Home
            </Link>
          </Nav.Link>
          <Nav.Link
            style={{
              color: "black",
              fontSize: "1.2rem",
              marginRight: "1.2rem",
            }}
          >
            <Link
              to="/about"
              style={{ textDecoration: "none", color: "black" }}
            >
              About Us
            </Link>
          </Nav.Link>
          <Nav.Link
            style={{
              color: "black",
              fontSize: "1.2rem",
              marginRight: "1.2rem",
            }}
          >
            <Link
              to="/houses"
              style={{ textDecoration: "none", color: "black" }}
            >
              Houses
            </Link>
          </Nav.Link>
          <Nav.Link
            style={{
              color: "black",
              fontSize: "1.2rem",
              marginRight: "1.2rem",
            }}
          >
            <Link
              to="/contact"
              style={{ textDecoration: "none", color: "black" }}
            >
              Contact Us
            </Link>
          </Nav.Link>
          <Link
            to="/listProperty"
            style={{ textDecoration: "none", color: "black" }}
            className="mx-2"
          >
            <Button variant="primary">List Property</Button>
          </Link>
          <Link to="/login" className="mx-2" style={{ textDecoration: "none", color: "black" }}>
            <Button variant="primary">Login</Button>
          </Link>
        </Nav>
      </Navbar.Collapse>
    </Navbar>
  );
};

export default AppNavbar;
