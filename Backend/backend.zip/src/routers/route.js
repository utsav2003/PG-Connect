const express = require("express");
const route = express.Router();

const jwt = require("jsonwebtoken");
const transporter = require("../mail/mailer.js");

//userReg Model import
const userReg = require("../models/userReg.js");
const pgReg = require("../models/regPG.js");

//for Insert data request
route.post("/userReg", async (req, res) => {
  try {
    const user = new userReg(req.body);
    const insert = await user.save();

    res.send(insert);
  } catch (err) {
    res.status(400).send(err);
  }
});

module.exports = route;
